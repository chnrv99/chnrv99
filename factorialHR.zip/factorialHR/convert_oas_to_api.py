import os
import json
import logging
import chardet
# from prance import ResolvingParser
import jsonref
import json
from urllib.parse import urljoin
import jsonpickle


logging.getLogger("prance").addHandler(logging.NullHandler())
logging.getLogger('openapi_spec_validator').setLevel(logging.CRITICAL)

def detect_file_encoding(file_path):
    with open(file_path, 'rb') as file:
        raw_data = file.read()
        result = chardet.detect(raw_data)
        encoding = result.get('encoding')
        return encoding.lower() if encoding else 'utf-8'

def parse_and_resolve_openapi_spec(input_file):
    encoding = detect_file_encoding(input_file)
    print(f"Detected encoding: {encoding}")
    # parser = ResolvingParser(input_file, backend='openapi-spec-validator')
    return parser.specification

def resolve_json_references_with_jsonref(json_path):
    encoding = detect_file_encoding(json_path)
    print(f"Detected encoding: {encoding}")
    with open(json_path, 'r', encoding=encoding) as file:
        json_data = json.load(file)
    resolved_data = jsonref.replace_refs(json_data)
    return resolved_data

def write_resolved_spec_to_file(spec, output_file):
    serialized_data = jsonpickle.dumps(spec)

    # Write to file with proper indentation using json module
    with open(output_file, 'w', encoding='utf-8') as outfile:
        # Load data with json to apply indentation
        data = json.loads(serialized_data)
        json.dump(data, outfile, indent=4)

def resolve_using_jsonref(input_file, output_file):
    resolved_data = resolve_json_references_with_jsonref(input_file)
    write_resolved_spec_to_file(resolved_data, output_file)
    
def process_openapi_spec(api_spec_file):
    encoding = detect_file_encoding(api_spec_file)
    with open(api_spec_file, 'r', encoding=encoding) as file:
        openapi_spec = json.load(file) 
    print(len(openapi_spec)) 
    api_details = {} 
    if isinstance(openapi_spec, dict):
        openapi_spec = [openapi_spec]  
        
    for item in openapi_spec:
        base_urls = [server['url'].rstrip('/') + '/' for server in item.get('servers', [])]
        base_url = base_urls[0] if base_urls else ''

        for path, path_data in item.get('paths', {}).items():
            parameters = []
            if path_data.get("parameters"):
                parameters = path_data.pop("parameters")
            if path_data.get("parameters"):
                parameters = path_data.pop("parameters")
            for method, method_data in path_data.items():
                clean_path = path.lstrip('/')

                # Join base URL and path correctly
                full_url = urljoin(base_url, clean_path)
                api_id = f"{full_url} {method.upper()}"
                if "X-INTERNAL" in api_id:
                    print(f"Skipping Internal APIs -{api_id}")
                    continue
                else:
                    print(api_id)        
                    api_details[api_id] = {
                        'tags': method_data.get('tags', []),
                        'summary': method_data.get('summary', None),
                        'description': method_data.get('description', None),
                        'parameters': method_data.get('parameters', parameters),
                        'requestBody': method_data.get('requestBody'),
                        'responses': method_data.get('responses')
                    }
    return api_details


def resolve_json_references(root_directory, output_directory):
    # Ensure the output directory exists
    os.makedirs(output_directory, exist_ok=True)
    
    for root, dirs, files in os.walk(root_directory):
        for file_name in files:
            if file_name.endswith('.json'):
                file_path = os.path.join(root, file_name)
                base_path = os.path.splitext(file_name)[0]
                if base_path.endswith("resolved"):
                    continue
                encoding = detect_file_encoding(file_path)
                with open(file_path, 'r', encoding=encoding) as file:
                    try:
                        # Load the JSON data
                        data = json.load(file)
                        # oas_def = data
                        
                        # Resolve references
                        
                       
                        resolved_data = jsonref.replace_refs(data)
                    
                        output_file_name = f"{os.path.splitext(file_name)[0]}_resolved.json"
                        output_file_path = os.path.join(output_directory, output_file_name)
                        write_resolved_spec_to_file(resolved_data, output_file_path)
                        # Save the resolved JSON data
                        # with open(output_file_path, 'w') as output_file:
                        #     json.dump(resolved_data, output_file, indent=4)
                            
                        print(f"Resolved and saved JSON: {output_file_path}")
                    except json.JSONDecodeError as e:
                        print(f"Error decoding JSON in file {file_path}: {e}")
                    except Exception as e:
                        print(f"An error occurred while processing file {file_path}: {e}")
                        
def combined_oas_defs(root_directory, output_directory):
    # Ensure the output directory exists
    os.makedirs(output_directory, exist_ok=True)
    oas_def_combined = []
    
    for root, dirs, files in os.walk(root_directory):
        for file_name in files:
            if file_name.endswith('.json'):
                file_path = os.path.join(root, file_name)
                
                with open(file_path, 'r') as file:
                    try:
                        # Load the JSON data
                        data = json.load(file)
                        oas_def_combined.append(data)
                    except Exception as e:
                        print(f"An error occurred while processing file {file_path}: {e}")                        
    
    output_file_name = "oas_def.json"
    output_file_path = os.path.join(output_directory, output_file_name)
    with open(output_file_path, 'w') as output_file:
        json.dump(oas_def_combined, output_file, indent=4)            
  
    
    

if __name__ == "__main__":
    # base_dir = os.path("UKG PRO")
    # input_file_path = os.path.join(base_dir, "oas_def.json")
    # output_file_path = os.path.join(base_dir, "oas_def_resolved.json")
    # resolve_using_jsonref(input_file_path, output_file_path)
    
    # base_dir = os.path.join("output_folder", "resolved_oas")
    
    
    resolve_json_references("./jsons", "./resolved_json_directory")
    combined_oas_defs("./resolved_json_directory", "./resolved_json_directory")
    
    # os.makedirs(base_dir, exist_ok=True)

    # using_jsonref = True  # Set to True to use the new parsing logic

    # if using_jsonref:
    #     resolve_using_jsonref(input_file_path, output_file_path)
    # else:
    #     resolved_spec = parse_and_resolve_openapi_spec(input_file_path)
    #     write_resolved_spec_to_file(resolved_spec, output_file_path)
    
    # Fetching ALL API ID and Processing Json
    # # oas_def_path = os.path.join(base_dir, "oas_def.json")
    api_data = process_openapi_spec("E:\\files to send - Copy\\factorialHR\\jsons\\factorial.json")
    print(len(api_data))
    # print(api_data["https://dc1demogwext.paylocity.com/apiHub/security/v1/companies/b6001/companyOnboardingStatuses PUT"])
    # count = 0

# Now you can access individual API details like this:
    # for api_id, details in api_data.items():
    #     print(f"API ID: {api_id}")
        # print(details)
        # if count > 2:
        #     break
        # print(f"  Summary: {details['requestBody']}")
        # print(f"  Description: {details['']}")
    # ... access other details like parameters, requestBody, responses ...      

