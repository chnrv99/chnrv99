from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from bs4 import BeautifulSoup
import time
import urllib
import re
import os

def save_file(file_path, content):
    """
    Save content to a file at the specified path.
    """
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)

def sanitize_filename(name):
    # Remove invalid characters
    return re.sub(r'[<>:"/\\|?*]', '', name)

def fetch_page_content(url):
    return url

def createFolderStructureForReadme(url, base_folder):
    options = Options()
    options.headless = True
    driver = webdriver.Chrome(options=options)
    driver.get(url)
    time.sleep(10)  # Allowing time for the page to fully load
    page_source = driver.page_source
    driver.quit()
    soup = BeautifulSoup(page_source, 'html.parser')
    base_domain = urllib.parse.urlparse(url).netloc
    div = soup.find('div', class_='Sidebar1t2G1ZJq-vU1 rm-Sidebar hub-sidebar-content')
    sections = div.find_all('section', class_='Sidebar-listWrapper6Q9_yUrG906C rm-Sidebar-section')
    structure = []
    for section in sections:
        heading = section.find('h2', class_='Sidebar-headingTRQyOa2pk0gh rm-Sidebar-heading')
        section_name = sanitize_filename(heading.text)
        print(f"Section - {section_name}")
        section_data = {'name': section_name, 'children': []}
        folders = section.find_all('ul', class_='Sidebar-list3cZWQLaBf9k8 rm-Sidebar-list')
        for folder in folders:
            folder_items = folder.find_all('li', recursive=False)
            for folder_item in folder_items:
                folder_name = sanitize_filename(folder_item.find('span').text)
                folder_url = folder_item.find('a')['href']
                if base_domain == base_domain or base_domain == '':
                    folder_url = urllib.parse.urljoin(url, folder_url)
                folder_data = {'name': folder_name, 'children': [], 'url': folder_url}
                print(f"  Folder - {folder_name} and URL - {folder_url}")
                subfolders = folder_item.find_all('ul', recursive=False)
                for subfolder in subfolders:
                    subfolder_items = subfolder.find_all('li', recursive=False)
                    for subfolder_item in subfolder_items:
                        subfolder_name = sanitize_filename(subfolder_item.find('span').text)
                        subfolder_url = subfolder_item.find('a')['href']
                        if base_domain == base_domain or base_domain == '':
                            subfolder_url = urllib.parse.urljoin(url, subfolder_url)
                        subfolder_data = {'name': subfolder_name, 'children': [], 'url': subfolder_url}
                        print(f"    Subfolder - {subfolder_name} and URL - {subfolder_url}")
                        pages = subfolder_item.find_all('li')
                        for page in pages:
                            page_text = sanitize_filename(page.find('span').text)
                            page_url = page.find('a')['href']
                            if base_domain == base_domain or base_domain == '':
                                page_url = urllib.parse.urljoin(url, page_url)
                            page_data = {'name': f"{page_text}.txt", 'url': page_url}
                            print(f"      Page - {page_data['name']} and URL - {page_url}")
                            subfolder_data['children'].append(page_data)
                        folder_data['children'].append(subfolder_data)
                section_data['children'].append(folder_data)
        structure.append(section_data)
    # Process structure and create files/folders
    for section in structure:
        section_path = os.path.join(base_folder, section['name'])
        if not os.path.exists(section_path):
            os.makedirs(section_path)
        for folder in section['children']:
            folder_path = os.path.join(section_path, folder['name'])
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
            if 'children' in folder and folder['children']:
                for subfolder in folder['children']:
                    if 'children' in subfolder and subfolder['children']:  # Subfolder with pages
                        subfolder_path = os.path.join(folder_path, subfolder['name'])
                        if not os.path.exists(subfolder_path):
                            os.makedirs(subfolder_path)
                        for page in subfolder['children']:
                            file_path = os.path.join(subfolder_path, page['name'])
                            page_content = fetch_page_content(page['url'])
                            save_file(file_path, page_content)
                    else:  # Subfolder with no pages
                        subfolder_file_path = os.path.join(folder_path, f"{subfolder['name']}.txt")
                        subfolder_content = fetch_page_content(subfolder['url'])
                        save_file(subfolder_file_path, subfolder_content)
                    folder_file_path = os.path.join(section_path, f"{folder['name']}.txt")
                    folder_content = fetch_page_content(folder['url'])
                    save_file(folder_file_path, folder_content)
            else:  # Folder with no subfolders
                folder_file_path = os.path.join(section_path, f"{folder['name']}.txt")
                folder_content = fetch_page_content(folder['url'])
                save_file(folder_file_path, folder_content)


if __name__ == "__main__":
    url = "https://apidoc.factorialhr.com/v2.0/reference/get_api-v2-resources-api-public-credentials"
    base_folder = "./folder_structure"
    createFolderStructureForReadme(url, base_folder)




